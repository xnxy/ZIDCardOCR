//
//  ZIDCardOCR.h
//  ZIDCardOCR
//
//  Created by CNTP on 2019/11/13.
//

#import <UIKit/UIKit.h>

//! Project version number for ZIDCardOCR.
FOUNDATION_EXPORT double ZIDCardOCRVersionNumber;

//! Project version string for ZIDCardOCR.
FOUNDATION_EXPORT const unsigned char ZIDCardOCRVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZIDCardOCR/PublicHeader.h>
#import <ZIDCardOCR/ZIDCardOCRManager.h>
#import <ZIDCardOCR/ZIDCardInfo.h>


